#include "arithmetic.h"
Arithmetic::Arithmetic() {
}
Arithmetic::Arithmetic(const Arithmetic &rhs) {
}
Arithmetic::~Arithmetic() {
}
