#include "arithmetic.h"
Arithmetic::Arithmetic() {
}
Arithmetic::~Arithmetic() {
}