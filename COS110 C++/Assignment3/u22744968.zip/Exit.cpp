#include "Exit.h"

Exit::Exit(int x, int y): Object(x, y)
{
    icon = '@';
    solid = false;
}
