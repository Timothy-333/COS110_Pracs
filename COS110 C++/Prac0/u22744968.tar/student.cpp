#include "student.h"
#include <iostream>

Student::Student()
{
}
Student::~Student()
{
}
void Student::sayHello()
{
    std::cout << "I u22744968 am a COS110 student. I pinky promise that I will work hard in this module and not cheat!!!";
    return;
}