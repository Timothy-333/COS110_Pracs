#include "student.h"
#include <iostream>
using namespace std;

Student student;
int main()
{
    student.sayHello();
    return 0;
}